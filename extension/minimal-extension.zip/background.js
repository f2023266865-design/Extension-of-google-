// Minimal background worker: simple message handlers for history
chrome.runtime.onMessage.addListener((msg, _sender, sendResponse)=>{
  if (msg?.type === 'get-history'){
    chrome.storage.local.get('minimal_history', (res)=> sendResponse({ history: res.minimal_history || [] }));
    return true;
  }
  if (msg?.type === 'clear-history'){
    chrome.storage.local.set({ minimal_history: [] }, ()=> sendResponse({ ok: true }));
    return true;
  }
});
