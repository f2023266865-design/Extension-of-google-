// Minimal content script: extract headings, main text, and code snippets
(function(){
  function getVisibleFallbackText(){
    const focused = document.querySelector('article, main, [role="main"], .markdown-body, .post-text, .answer, .question');
    const text = (focused && focused.innerText) || document.body.innerText || '';
    return text.replace(/\n{3,}/g,'\n\n').trim().slice(0,8000);
  }

  function extract(){
    try{
      const clone = document.cloneNode(true);
      clone.querySelectorAll('script, style, noscript, iframe, svg').forEach(n=>n.remove());

      const headings = Array.from(document.querySelectorAll('h1,h2,h3'))
        .map(n=>n.textContent?.trim()).filter(Boolean).slice(0,12).join('\n');

      const codes = Array.from(document.querySelectorAll('pre, code'))
        .map(n=>n.textContent?.trim()).filter(Boolean).slice(0,8).join('\n\n');

      // try to find article-like container
      const article = document.querySelector('article') || document.querySelector('main') || null;
      const mainText = article ? article.innerText.trim() : getVisibleFallbackText();

      const combined = [headings, mainText, codes].filter(Boolean).join('\n\n').slice(0,8000);
      return { content: combined || getVisibleFallbackText(), title: document.title, url: location.href };
    }catch(e){
      return { content: getVisibleFallbackText(), title: document.title, url: location.href };
    }
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse)=>{
    if (message && message.type === 'extract_content'){
      sendResponse(extract());
    }
  });

  // store last extraction for background/history
  window.addEventListener('visibilitychange', ()=>{
    if (document.visibilityState === 'hidden'){
      const snapshot = extract();
      chrome.storage.local.get('minimal_history', (res)=>{
        const history = res.minimal_history || [];
        history.unshift({ title: snapshot.title, url: snapshot.url, explanation: snapshot.content, createdAt: new Date().toISOString() });
        chrome.storage.local.set({ minimal_history: history.slice(0,25) });
      });
    }
  });
})();
