// Minimal popup script: requests content extraction from the active tab
const API_URL = '' // optional: set to https://your-vercel-app.vercel.app/api to call /explain

const el = id => document.getElementById(id);
const status = el('status');
const output = el('output');
const explainBtn = el('explainBtn');
const historyBtn = el('historyBtn');

function setStatus(t){ status.textContent = t }

explainBtn.addEventListener('click', async () => {
  setStatus('Requesting page content...');
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.id) throw new Error('No active tab');

    const extracted = await chrome.tabs.sendMessage(tab.id, { type: 'extract_content' });
    if (!extracted?.content) {
      output.textContent = 'No readable content found on this page.';
      setStatus('Done');
      return;
    }

    // show preview immediately
    output.textContent = `Title: ${extracted.title}\nURL: ${extracted.url}\n\nPreview:\n${extracted.content.slice(0,800)}...`;

    if (API_URL) {
      setStatus('Calling explain API...');
      const resp = await fetch(`${API_URL}/explain`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: extracted.content, userId: 'anonymous' })
      });

      const json = await resp.json();
      if (!resp.ok) {
        output.textContent = `API error: ${json?.error || resp.statusText}`;
      } else {
        output.textContent = json.explanation || JSON.stringify(json, null, 2);
      }
      setStatus('Done');
    } else {
      setStatus('No API configured — local preview shown');
    }
  } catch (err) {
    setStatus('Error');
    output.textContent = err?.message || String(err);
  }
});

historyBtn.addEventListener('click', async () => {
  const data = await chrome.storage.local.get('minimal_history');
  const list = data.minimal_history || [];
  if (!list.length) {
    output.textContent = 'No history saved.';
    return;
  }
  output.textContent = list.map((h)=>`${h.title} — ${h.url}\n${h.explanation.slice(0,200)}...`).join('\n\n');
});
